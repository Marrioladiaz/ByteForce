import TDA.TDAPila;
import Implementacion.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TDAPila P1E = new PilaEstatica();
		
		P1E.InicializarPila();
		
		TDAPila P2D = new PilaDinamica();
		
		P2D.InicializarPila();
		
		TDAPila aux = new PilaEstatica();
		
		aux.InicializarPila();
		
		System.out.println("Pila Estatica");
		P1E.Apilar(1);
		System.out.println(P1E.Tope());
		P1E.Apilar(2);
		System.out.println(P1E.Tope());
		P1E.Apilar(3);
		System.out.println(P1E.Tope());
		P1E.Apilar(4);
		System.out.println(P1E.Tope());
		P1E.Apilar(5);
		System.out.println(P1E.Tope());
		
		
		System.out.println("Pila Auxiliar");
		while (!P1E.PilaVacia()) {
			int x = P1E.Tope();
			P1E.Desapilar();
			aux.Apilar(x);
			System.out.println(x);
		}
		
		System.out.println("Pila Dinamica");
		while (!aux.PilaVacia()) {
			int y = aux.Tope();
			aux.Desapilar();
			P2D.Apilar(y);
			System.out.println(y);
		}
		
	}

}
